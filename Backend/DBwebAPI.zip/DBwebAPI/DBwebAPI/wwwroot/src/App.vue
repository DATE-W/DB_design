<script>
export default {
    name: 'App',
}
</script>

<template>
  <RouterView />
</template>

<style scoped>
#app {
    width: 100%;
    height: 100%;
}
</style>
